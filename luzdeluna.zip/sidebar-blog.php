<div class="col-md-3 sidebar">

	<?php if ( ! dynamic_sidebar( 'blog' ) ): ?>
	<h3>Sidebar Setup</h3>
	<p>Please, add widgets to the blog sidebar to get them displayed here.</p>

	<?php endif; ?>
</div>
