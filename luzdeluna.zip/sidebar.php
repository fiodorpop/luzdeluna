<div class="col-md-3 sidebar sidebar-offcanvas">

	<?php if ( ! dynamic_sidebar( 'page' ) ): ?>
	<h3>Sidebar Setup</h3>
	<p>Please, add widgets to the page sidebar to get them displayed here.</p>

	<?php endif; ?>
</div>
